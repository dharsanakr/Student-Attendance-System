from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from django.contrib import messages

from .models import Teacher, Student, Subject, Attendance

# ✅ Teacher Login
def teacher_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)

        if user is not None:
            try:
                teacher = Teacher.objects.get(user=user)
                login(request, user)
                return redirect('dashboard')
            except Teacher.DoesNotExist:
                return render(request, 'login.html', {'error': 'Not a registered teacher'})
        else:
            return render(request, 'login.html', {'error': 'Invalid credentials'})
    return render(request, 'login.html')


# ✅ Logout
def teacher_logout(request):
    logout(request)
    return redirect('login')


# ✅ Dashboard
@login_required
def dashboard(request):
    teacher = Teacher.objects.get(user=request.user)
    return render(request, 'dashboard.html', {'teacher': teacher})


# ✅ Mark Attendance
@login_required
def mark_attendance(request):
    teacher = Teacher.objects.get(user=request.user)
    students = Student.objects.all()

    if request.method == 'POST':
        date = request.POST.get('date')
        for student in students:
            status = request.POST.get(f'status_{student.id}')
            Attendance.objects.update_or_create(
                student=student,
                subject=teacher.subject,
                date=date,
                defaults={'status': status}
            )
        messages.success(request, "Attendance successfully saved!")
        return redirect('mark_attendance')

    today = timezone.now().date()
    return render(request, 'mark_attendance.html', {
        'students': students,
        'today': today,
    })


# ✅ View Attendance Summary (Teacher)
@login_required
def view_attendance(request):
    teacher = Teacher.objects.get(user=request.user)
    subject = teacher.subject
    students = Student.objects.all()

    attendance_data = []
    for student in students:
        total = Attendance.objects.filter(subject=subject, student=student).count()
        present = Attendance.objects.filter(subject=subject, student=student, status='Present').count()
        percentage = round((present / total) * 100, 2) if total > 0 else 0

        attendance_data.append({
            'student': student,
            'total': total,
            'present': present,
            'percentage': percentage,
        })

    return render(request, 'view_attendance.html', {'data': attendance_data, 'subject': subject})





from django.shortcuts import render, get_object_or_404
from .models import Student, Attendance, Subject
from django.db.models import Count, Sum

def student_profile(request, student_id):
    student = get_object_or_404(Student, id=student_id)
    
    subjects = Subject.objects.all()
    data = []

    for subject in subjects:
        attendance_qs = Attendance.objects.filter(student=student, subject=subject)
        total = attendance_qs.count()
        present = attendance_qs.filter(status=True).count()
        percentage = round((present / total) * 100, 2) if total > 0 else 0

        data.append({
            'subject': subject,
            'present': present,
            'total': total,
            'percentage': percentage
        })

    context = {
        'student': student,
        'data': data,
    }
    return render(request, 'student_profile.html', context)
